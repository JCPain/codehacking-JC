@extends('layouts.app')

@section('content')
    <h1 class="text-center">Oops, no page available</h1>
@stop