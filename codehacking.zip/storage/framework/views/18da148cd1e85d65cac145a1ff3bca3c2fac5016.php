<?php $__env->startSection('content'); ?>
    <h1>Posts</h1>
    <?php if(Session::has('msg-created')): ?>
        <p class="bg-success"><?php echo e(session('msg-created')); ?></p>
    <?php elseif(Session::has('msg-updated')): ?>
        <p class="bg-info"><?php echo e(session('msg-updated')); ?></p>
    <?php elseif(Session::has('msg-deleted')): ?>
        <p class="bg-danger"><?php echo e(session('msg-deleted')); ?></p>
    <?php endif; ?>
    <table class="table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Photo</th>
                <th>Owner</th>
                <th>Category</th>
                <th>Title</th>
                <th>Body</th>
                <th>Created</th>
                <th>Updated</th>
            </tr>
        </thead>
        <tbody>
            <?php if($posts): ?>
                <?php foreach($posts as $post): ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td><img height="50" width="70" src="<?php echo e($post->photo ? $post->photo->file : 'https://source.unsplash.com/featured/?sky'); ?>" alt=""></td>
                        <td><a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>"><?php echo e($post->user->name); ?></a></td>
                        <td><?php echo e($post->category ? $post->category->name : 'Uncategorized'); ?></td>
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e(str_limit($post->body, 30)); ?></td>
                        <td><?php echo e($post->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($post->updated_at->diffForHumans()); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>